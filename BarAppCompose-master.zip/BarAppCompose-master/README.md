# BarAppCompose

An Android Application developed with Kotlin and Jetpack Compose for the layout design.
The purpose of this application is to be used in a thesis project. 
